<?php
function checkPath($path) {
    preg_match("^[\\/:*?*<>|]$",$path,$match);
    var_dump($match);
}
// checkPath("/a/b/c/d/");

function is_pic_file($ext){
	$ext_arr = array(
		"bmp","jpg","jpeg","png","gif"
	);
	if(in_array($ext,$ext_arr)){
		return true;
	} else {
		return false;
	}
}

function is_vd_file($ext){
	$ext_arr = array(
		"mp4","mov","mkv","avi","wmv","m4v","xvid","asf","dv","mpeg","vob","webm","ogv","divx","3gp","mxf","ts","trp","mpg","flv","f4v","swf"
	);
	if(in_array($ext,$ext_arr)){
		return true;
	}else{
		return false;
	}
}

function is_audio_file($ext){
	$ext_arr = array(
		"mp3","wav","m4a","wma","aac","flac","ac3","aiff","m4b","m4r","au","ape","mka","ogg","mid"
	);
	if(in_array($ext,$ext_arr)){
		return true;
	}else{
		return false;
	}
}

function ext_type($ext) {//我没有做那么全,够用即可
	if(is_text_file($ext)) {
		return "text";
	}
	if(is_pic_file($ext)) {
		return "image";
	}
	if(is_vd_file($ext)) {
		return "video";
	}
	if(is_audio_file($ext)) {
		return "audio";
	}
	return false;
}

function parseRealPath($virtualPath) {
    if($virtualPath=="") {
        return "";
    }
    $virtualFolderName = strstr($virtualPath,"/",true);
    $realPath = FOLDER_LIST[$virtualFolderName].strstr($virtualPath,"/");
    return [
        "realPath" => $realPath,
        "virtualFolderName" => $virtualFolderName
    ];
}

function pasteVirtualPath($realPath,$virtualFolderName) {
    if($realPath=="") {
        return "";
    }
    $virtualPath = substr($realPath,strlen(FOLDER_LIST[$virtualFolderName]));
    $virtualPath = $virtualFolderName.$virtualPath;
    return $virtualPath;
}
/**
 * 最慢的缓存，能用即可
 */
function cacheSet($dir,$tag,$value) {
    $cachefile = $dir.".comic_reader.cache";
    if(!file_exists($cachefile)) {
        file_put_contents($cachefile,"{}");
    }
    
    $cache = json_decode(file_read_safe($cachefile),true);
    $cache[$tag] = $value;
    file_wirte_safe($cachefile,json_encode($cache));
    return $value;
}

function cacheGet($dir,$tag) {
    $cachefile = $dir.".comic_reader.cache";
    if(!file_exists($cachefile)) {
        file_put_contents($cachefile,"{}");
    }
    
    $cache = json_decode(file_read_safe($cachefile),true);
    // 判断是否定义和是否为NULL
    if(isset($cache[$tag])) {
        return $cache[$tag];
    }
    return false;
}

function clearCache($dir) {
    return del_file($dir.".comic_reader.cache");
}

function getCover($dir) { 
    $picPath = cacheGet($dir,"cover");
    if($picPath!=false) {
        // echo $picPath;
        if(file_exists($dir.$picPath)) {
            // echo $picPath;
            return $picPath;
        }
    }
    // 获取目录下文件（夹）
    $file = path_list($dir);
    foreach ($file["fileList"] as $k => $v) {
        if(is_pic_file($v["ext"])) {
            return cacheSet($dir,"cover",$v["name"]);
            break;
        }
    }
    // 深层递归查找
    foreach ($file["folderList"] as $k => $v) {
        $picPath = getCover($dir.$v["name"]."/");
        if($picPath!=false) {
            return cacheSet($dir,"cover",$v["name"]."/".$picPath);
        }
    }
    // return cacheSet($dir,"cover",false);
    return false;
}

function comicInfoOutPut($v,$virtualPath,$options=["more"=>""]) {
    if(!isset($v["isParent"])) {
        $v["isParent"] = path_haschildren($v["path"],false);
    }
    
    // 获取pichtml
    if(!isset($options["picHtml"])) {
        if(!isset($options["picUrl"])) {
            $options["picUrl"] = getCover($v["path"]);
        }
        if($options["picUrl"]!=false) {
            $options["picHtml"] = "<img class=\"img-thumbnail lazyload\" style=\"width: 100%\" data-src=\"".APP_URL."file.php?path=".urlencode($virtualPath.$options["picUrl"])."\"/>";
        } else {
            $options["picHtml"] = "";
        }
    }
    
    // 获取要去往的地方
    if(!isset($options["toUrl"])) {
        $options["toUrl"] = APP_URL;
        if($v["isParent"]) {
            $options["toUrl"] .= "index.php?";
        } else {
            $options["toUrl"] .= "view.php?";
        }
        $options["toUrl"] .= "path=".urlencode($virtualPath);
    }
    
    $html = "
<div class=\"col-md-3 col-sm-4 col-6 mb-3 d-flex align-self-stretch\">
    <div class=\"card bg-transparent border\" style=\"width: 100%\">
        <div class=\"card-body\">
            <a href=\"".$options["toUrl"]."\" target=\"_blank\">
                ".$options["picHtml"]."
                <h5>".$v["name"]."</h5>
            </a>
            <a href=\"".APP_URL."view.php?path=".urlencode($virtualPath)."\" onclick=\"return top.hs.htmlExpand(this, {objectType: 'iframe'} )\" class=\"highslide\">预览</a>
            ".$options["more"]."
        </div>
    </div>
</div>";
    return $html;
}

// 大部分情况下能用就好了
function getPathList($virtualPath,$global=true) {
    // 我这么做是有风险的，如要映射到外网请谨慎！！！
    if(isset($virtualPath)&&$virtualPath!="") {
        $folderData = parseRealPath($virtualPath);
        $realPath = $folderData["realPath"];
        $virtualFolderName = $folderData["virtualFolderName"];
        $fileName = end(explode("/",$virtualPath));
        $files = path_list($realPath,false,true);
        if($global) {
            $GLOBALS["virtualPath"]=$virtualPath;
            $GLOBALS["realPath"]=$realPath;
            $GLOBALS["virtualFolderName"]=$virtualFolderName;
            $GLOBALS["fileName"]=$fileName;
        }
    } else {
        $files = array(
            "fileList" => array(),
            "folderList" => array()
        );
        foreach (FOLDER_LIST as $k => $v) {
            if(is_dir($v)) {
                $folderInfo = folder_info($v); 
                $folderInfo["name"] = $k;
                // array_push有好处的，比如我不用考虑下标[doge]
                array_push($files["folderList"],$folderInfo);
            }
        }
    }
    return $files;
}