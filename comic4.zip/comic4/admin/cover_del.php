<?php
define("ROOT_PATH","../");
include ROOT_PATH."config/config.php";

if(!isset($_GET["path"])) {
    exit("exit");
}

ob_end_clean();
ob_implicit_flush(1);

echo "<h1>清除封面缓存</h1><table style='width: 100%'><th>path</th>";

$files = getPathList($_GET["path"]);
foreach ($files["folderList"] as $k => $v) {
    $caches = path_search($v["path"],".comic_reader.cache");
    foreach ($caches["fileList"] as $ke => $va) {
        // 避免有人闲的起混淆的名字
        if($va["name"] == ".comic_reader.cache") {
            echo "<tr><td>".pasteVirtualPath($va["path"],$v["name"])."</td></tr>";
            cacheSet(get_path_father($va["path"]),"cover",null);
        }
    }
}
echo "</table>over!";