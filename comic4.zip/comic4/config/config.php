<?php
@date_default_timezone_set(@date_default_timezone_get());
@set_time_limit(1200);//20min pathInfoMuti,search,upload,download...
@ini_set("max_execution_time",1200);
@ini_set('memory_limit','500M');//
@ini_set('session.cache_expire',1800);
@ini_set("display_errors","on");
@error_reporting(E_ALL^E_NOTICE^E_WARNING^E_DEPRECATED);

header("Content-type: text/html; charset=utf-8");
define('BASIC_PATH',str_replace('\\','/',dirname(dirname(__FILE__))).'/');

include(ROOT_PATH."config/config.user.php");
include(ROOT_PATH.'function/common.function.php');
include(ROOT_PATH.'function/web.function.php'); 
include(ROOT_PATH.'function/file.function.php');
include(ROOT_PATH.'function/helper.function.php');
include(ROOT_PATH.'function/comic_reader.function.php');

$config['appStartTime'] = mtime();
$config['appCharset']	= 'utf-8';//该程序整体统一编码
$config['checkCharsetDefault'] = '';//if set,not check;

//when edit a file ;check charset and auto converto utf-8;
if (strtoupper(substr(PHP_OS, 0,3)) === 'WIN') {
	$config['systemOS']='windows';
	$config['systemCharset']='gbk';// EUC-JP/Shift-JIS/BIG5  //user set your server system charset
	if(version_compare(phpversion(), '7.1.0', '>=')){//7.1 has auto apply the charset
		$config['systemCharset']='utf-8';
	}
} else {
	$config['systemOS']='linux';
	$config['systemCharset']='utf-8';
}

// 部分反向代理导致获取不到url的问题优化;忽略同域名http和https的情况
if(isset($_COOKIE['APP_HOST'])){
	if( get_url_domain($_COOKIE['HOST']) != get_url_domain($_COOKIE['APP_HOST']) ||
	    get_url_scheme($_COOKIE['HOST']) == get_url_scheme($_COOKIE['APP_HOST']) ){
		define('HOST',$_COOKIE['HOST']);
		define('APP_HOST',$_COOKIE['APP_HOST']);
	}
}
if(!defined('HOST')){
    define('HOST',rtrim(get_host(),'/').'/');
}
if(!defined('WEB_ROOT')){
    define('WEB_ROOT',webroot_path(BASIC_PATH) );
}
if(!defined('APP_HOST')){
    define('APP_HOST',HOST.str_replace(WEB_ROOT,'',BASIC_PATH));
} //程序根目录