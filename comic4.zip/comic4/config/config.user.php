<?php
// 这些是例子，要根据自己的情况填
// 网站网址
define("APP_URL","http://192.168.1.200/comic4/");
// 网站名称
define("APP_NAME","Comic4");
// 网站ico图标
define("ICO_URL","http://192.168.1.200/comic4/logo.ico");
// 要求，最后不带‘/’，要不会出大问题
// 必须用绝对目录！！！必须用绝对目录！！！必须用绝对目录！！！
define(FOLDER_LIST,array(
        "s" => "/var/www/suntra/s",
    ));
