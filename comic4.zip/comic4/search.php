<?php
define("ROOT_PATH", "");
include ROOT_PATH."config/config.php";
include ROOT_PATH."smarty.php";

$searchStr = $_GET["q"];
// ===== header =====
$pageHeader = "
<div class=\"page-header\">
    <h1>搜索页 <small>不知道写什么。。。</small></h1>
</div>
<form action=\"search.php\" method=\"get\" class=\"input-group\">
    <input class=\"form-control text-white bg-white bg-opacity-25\" type=\"text\" name=\"q\">
    <input class=\"btn btn-outline-light\" type=\"submit\" value=\"搜索\">
</form>
搜索很慢，我做这个功能是为了查重的（避免下载重复）
";
$smarty->assign("pageHeader",$pageHeader);
// ===== content =====
$pageContent = "<div class=\"row\">";
if($searchStr!="") {
    foreach (FOLDER_LIST as $k => $v) {
        $files = path_search($v, $searchStr);
        $folderList = $files["folderList"];
        foreach ($folderList as $key => $value) {
            $pageContent .= comicInfoOutPut($value,pasteVirtualPath($value["path"],$k),"From: ".$k);
        }
    }
}
$pageContent .= "<center>------ 到底了呢 ------</center></div>";
$smarty->assign("pageContent",$pageContent);
// ===== footer =====
$pageFooter = "<p>dffxd</p>";
$smarty->assign("pageFooter",$pageFooter);
// ===== display =====
$smarty->assign("page","search");
$smarty->assign("ICO_URL",ICO_URL);
$smarty->assign("title",APP_NAME." - 搜索 - ".htmlspecialchars($searchStr));
$smarty->assign("APP_URL",APP_URL);
$smarty->assign("APP_NAME",APP_NAME);
$smarty->display('template/main.tpl');