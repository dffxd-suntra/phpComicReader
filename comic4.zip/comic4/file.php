<?php
define("ROOT_PATH","");
include ROOT_PATH."config/config.php";
file_put_out(parseRealPath($_GET["path"])["realPath"]);