本应用大部分借鉴模仿 kodcloud 的应用
我会遵守 GNU3.0