<?php
define("ROOT_PATH","");
include ROOT_PATH."config/config.php";
include ROOT_PATH."smarty.php";

// 处理get
// 每个文件单独解析get，避免事故
$virtualPath = $_GET["path"];
// echo $virtualPath;
$folderData = parseRealPath($virtualPath);
$realPath = $folderData["realPath"];
$virtualFolderName = $folderData["virtualFolderName"];
$fileName = end(explode("/",$virtualPath));

// 递归获取这个文件夹下的所有文件
function getFile($path) {
    global $realPath;
    // 获取文件（以后迟早有缓存
    $files = path_list($realPath.$path);
    $fileList = array();
    foreach ($files["folderList"] as $k => $v) {
        $fileList = array_merge($fileList,getFile($path.$v["name"]."/"));
    }
    foreach ($files["fileList"] as $k => $v) {
        $files["fileList"][$k]["path"] = $path.$v["name"];
    }
    return array_merge($fileList,$files["fileList"]);
}

$fileList = getFile("");

// ===== content =====
$pageContent = "";
foreach ($fileList as $k => $v) {
    $fileType = ext_type($v["ext"]);
    // 不想用switch，不好用
    if($fileType=="image") {
        $pageContent .= "
<li>
    <img src=\"".APP_URL."file.php?path=".urlencode($virtualPath.$v["path"])."\" art=\"".$v["name"]."\" style=\"width: 100%;\" class=\"lazyload\"/>
</li>
";
    }
    if($fileType=="video") {
        $pageContent .= "
<li>
    <div id=\"dplayer".$k."\" style=\"width: 100%;\"></div>
    <script>
    const dp".$k." = new DPlayer({
        container: document.getElementById('dplayer".$k."'),
        video: {
            url: '".APP_URL."file.php?path=".urlencode($virtualPath.$v["path"])."',
        },
    });
    </script>
</li>";
    }
    if($fileType=="audio") {
        $pageContent .= "
<li>
    <div id=\"aplayer".$k."\" style=\"width: 100%;\"></div>
    <script>
    const ap".$k." = new APlayer({
        container: document.getElementById('aplayer".$k."'),
        audio: [{
            name: '".$v["name"]."',
            url: '".APP_URL."file.php?path=".urlencode($virtualPath.$v["path"])."'
        }]
    });
    </script>
</li>
";
    }
}
$smarty->assign("pageContent",$pageContent);
// ===== footer =====
$pageFooter = "<p>dffxd</p>";
$smarty->assign("pageFooter",$pageFooter);
// ===== display =====
$smarty->assign("page","view");
$smarty->assign("virtualPath",$virtualPath);
$smarty->assign("realPath",$realPath);
$smarty->assign("virtualFolderName",$virtualFolderName);
$smarty->assign("fileName",$fileName);
$smarty->assign("ICO_URL",ICO_URL);
$smarty->assign("title",chop(APP_NAME." - 预览 - 主页/".htmlspecialchars($virtualPath),"/"));
$smarty->assign("APP_URL",APP_URL);
$smarty->assign("APP_NAME",APP_NAME);
$smarty->display('template/view.tpl');