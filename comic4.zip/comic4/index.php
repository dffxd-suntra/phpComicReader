<?php
define("ROOT_PATH","");
include ROOT_PATH."config/config.php";
include ROOT_PATH."smarty.php";

$files = getPathList($_GET["path"]);

$fileList = $files["fileList"];
$folderList = $files["folderList"];

// ===== header =====
$pageHeader = "
<div class=\"page-header\">
    <h1>发现页 <small>看？看！</small></h1>
</div>
<ul class='breadcrumb bg-transparent'>
    <li class='breadcrumb-item'><a href='?'>主页</a></li>
";
$explodePath = explode("/",$virtualPath);
$pathNow = "";
for($i=0;$i<sizeof($explodePath)-1;$i++) {
    $pathNow .= $explodePath[$i]."/";
    $pageHeader .= "<li class='breadcrumb-item'><a href='".APP_URL."index.php?path=".$pathNow."'>".htmlspecialchars($explodePath[$i])."</a></li>";
}
$pageHeader .= "</ul>";
$smarty->assign("pageHeader",$pageHeader);
// ===== content =====
$pageContent = "<div class=\"row\">";
foreach ($folderList as $k => $v) {
    $folderInfo["name"] = $virtualFolderName;
    $pageContent .= comicInfoOutPut($v,$virtualPath.$v["name"]."/");
}
$pageContent .= "<center>------ 到底了呢 ------</center></div>";
$smarty->assign("pageContent",$pageContent);
// ===== footer =====
$smarty->assign("pageFooter","");
// ===== display =====
$smarty->assign("page","index");
$smarty->assign("virtualPath",$virtualPath);
$smarty->assign("realPath",$realPath);
$smarty->assign("virtualFolderName",$virtualFolderName);
$smarty->assign("fileName",$fileName);
$smarty->assign("ICO_URL",ICO_URL);
$smarty->assign("title",chop(APP_NAME." - 发现页 - 主页/".htmlspecialchars($virtualPath),"/"));
$smarty->assign("APP_URL",APP_URL);
$smarty->assign("APP_NAME",APP_NAME);
$smarty->display('template/main.tpl');