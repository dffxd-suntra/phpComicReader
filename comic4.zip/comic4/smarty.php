<?php
include ROOT_PATH."smarty/libs/Smarty.class.php";
$smarty = new Smarty();
$smarty->setTemplateDir(ROOT_PATH.'smarty/template/');
$smarty->setConfigDir(ROOT_PATH.'smarty/config/');
$smarty->setCompileDir(ROOT_PATH.'smarty/compile/');
$smarty->setCacheDir(ROOT_PATH.'smarty/cache/');
// $smarty->testInstall();